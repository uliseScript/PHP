<?php
require_once '../config/config.php';
require_once '../config/database.php';
$db = new DataBase();
$con = $db->conectar();

$json = file_get_contents('php://input');
$datos = json_decode($json, true);

echo '<pre>';
print_r($datos);
echo '</pre>';

if (is_array($datos)) {
    // Obtener el id del cliente desde la sesión
    session_start();
    $idCliente = $_SESSION['user_cliente'];

    $sqlCliente = $con->prepare("SELECT email FROM clientes WHERE id=? AND estatus=1");
    $sqlCliente->execute([$idCliente]);
    $rowCliente = $sqlCliente->fetch(PDO::FETCH_ASSOC);

    $status = $datos['detalles']['status'];
    $fecha = $datos['detalles']['update_time'];
    $time = date("Y-m-d H:i:s", strtotime($fecha));
    $email = $rowCliente['email'];

    $monto = $datos['detalles']['purchase_units'][0]['amount']['value'];
    $idTransaccion = $datos['detalles']['id']; // Corregido el acceso al id de la transacción

    $comando = $con->prepare("INSERT INTO compra (fecha, status, email, id_cliente, total, id_transaccion) VALUES (?,?,?,?,?,?)");
    $comando->execute([$time, $status, $email, $idCliente, $monto, $idTransaccion]);

    $id = $con->lastInsertId();

    if ($id > 0) {
        $productos = isset($_SESSION['carrito']['productos']) ? $_SESSION['carrito']['productos'] : null;

        if ($productos != null) {
            foreach ($productos as $clave => $cantidad) {
                $sqlProd = $con->prepare("SELECT id, nombre, precio, descuento FROM productos WHERE id=? AND activo=1");
                $sqlProd->execute([$clave]);
                $rowProd = $sqlProd->fetch(PDO::FETCH_ASSOC);

                $precio = $rowProd['precio'];
                $descuento = $rowProd['descuento'];
                $precio_desc = $precio - (($precio * $descuento) / 100);

                $sql = $con->prepare("INSERT INTO detalle_compra (id_compra, id_producto, nombre, precio, cantidad) 
                    VALUES (?,?,?,?,?) ");
                $sql->execute([$id, $rowProd['id'], $rowProd['nombre'], $precio_desc, $cantidad]);
            }
            require_once 'Mailer.php';

            $asunto = "Detalles de su pedido";
            $cuerpo = '<h4>Gracias por su Compra</h4>';
            $cuerpo .= '<p>El ID de su compra es <b>' . $idTransaccion . '</b></p>';

            $mailer = new Mailer();
            $mailer->enviarEmail($email, $asunto, $cuerpo);
        }
        unset($_SESSION['carrito']);
    }
}
?>
