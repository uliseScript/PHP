<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'clases/clientefunciones.php';

$user_id= $_GET['id'] ?? $_POST['user_id'] ?? ''; //isset($_GET['id']) ? $_GET['id'] : '';
$token = $_GET['token'] ?? $_POST['token'] ?? '';

if($user_id == '' || $token == ''){
    header("Location: index.php");
    exit;
}

$db = new DataBase();
$con = $db->conectar();

$errors = [];

if(!verificaTokenRequest($user_id, $token, $con)){
    echo "No se puedo verificar la informacion";
    exit;
}




if (!empty($_POST)) {
    
    $password = trim($_POST['password']);
    $repassword = trim($_POST['repassword']);

    if (esNulo([$user_id, $token, $password, $repassword])) {
        $errors[] = "Debe llenar todos los campos";
    }


    if (!validaPassword($password, $repassword)) {
        $errors[] = "Las contraseñas no coinciden";
    }

    if(count($errors) == 0){
        $pass_hash = password_hash($password, PASSWORD_DEFAULT);
        if(actualizaPassword($user_id, $pass_hash, $con)){
            echo "Contraseña modificada.<br><a href='login.php'>Iniciar Ssesion</a>";
            exit;
        } else {
            $errors[] = "Error al modificar contraseña. Intentalo nuevamente";
        }
    }
    
    

    // if (count($errors) == 0) {
    //     // Operación exitosa, redirigir o mostrar mensaje de éxito
    // } else {
    //     print_r($errors);
    // }
}

//session_destroy();

//print_r($_SESSION)

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MaderaFina</title>
    <script src="https://kit.fontawesome.com/46ed41e555.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilos.css" rel="stylesheet">

    <style>
        /* Estilos personalizados */
        .navbar {
            background-color: #3e2723;
            /* Café oscuro */
        }

        .navbar-brand,
        .navbar-nav .nav-link {
            color: #fff;
            /* Letras blancas */
        }

        .btn-primary {
            background-color: #c1a174;
            /* Café claro */
            border-color: #c1a174;
            /* Café claro */
        }

        .btn-primary:hover {
            background-color: #c1a174;
            /* Café claro al pasar el mouse */
            border-color: #c1a174;
            /* Café claro al pasar el mouse */
        }

        .btn-outline-warning {
            color: #8b572a;
            /* Café medio */
            border-color: #8b572a;
            /* Café medio */
        }

        .btn-outline-warning:hover {
            background-color: #8b572a;
            /* Café medio al pasar el mouse */
            color: #fff;
            /* Texto blanco al pasar el mouse */
        }

        .btn-success {
            background-color: #8b572a;
            /* Café medio */
            border-color: #8b572a;
            /* Café medio */
        }

        .btn-success:hover {
            background-color: #6e4f29;
            /* Café oscuro al pasar el mouse */
            border-color: #6e4f29;
            /* Café oscuro al pasar el mouse */
        }

        .form-login {
            max-width: 350px;
        }
    </style>


</head>

<body>
    <header data-bs-theme="dark">

        <div class="navbar navbar-expand-lg navbar-dark" style="background-color: #3e2723;">

            <div class="container">
                <a href="#" style="margin-right: 10px;">
                    <img src="img/logo.jpg" alt="Logo de MaderaFina" class="img-fluid" style="max-height: 40px;">
                </a>
                <a href="#" class="navbar-brand">
                    <strong>MaderaFina</strong>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarHeader">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a href="#" class="nav-link active">Catalogo</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">Contacto</a>
                        </li>
                    </ul>
                    <a href="checkout.php" class="btn btn-primary">
                    <i class="fa-solid fa-cart-shopping"></i>
                        Carrito <span id="num_cart" class="badge bg-secondary"><?php echo $num_cart; ?></span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <main class="form-login m-auto pt-4">
        <h3>Cambiar Contraseña</h3>

        <?php mostrarMensajes($errors); ?>
        <form action="reset_password.php" method="post" class="row g-3" autocomplete="off">
            <input type="hidden" name="user_id" id="user_id" value="<?= $user_id; ?>">
            <input type="hidden" name="token" id="token" value="<?= $token; ?>">
        <div class="form-floating">
                <input class="form-control" type="password" name="password" id="password" placeholder="Nueva Contraseña">
                <label for="password">Nueva Contraseña</label>
            </div>
            <div class="form-floating">
                <input class="form-control" type="password" name="repassword" id="repassword" placeholder="Confirmar Contraseña">
                <label for="repassword">Confirmar Contraseña</label>
            </div>
            <div class="d-grid gap-3 col-12">
                <button type="submit" class="btn btn-primary">Continuar</button>
            </div>
            <hr>
            <div class="col-12">
                <a href="login.php">Iniciar Sesion</a>
            </div>
        </form>
    </main>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    


</body>

</html>