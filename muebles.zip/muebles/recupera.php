<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'clases/clientefunciones.php';

$db = new DataBase();
$con = $db->conectar();

$errors = [];
if (!empty($_POST)) {

    $email = trim($_POST['email']);

    if (esNulo([$email])) {
        $errors[] = "Debe llenar todos los campos";
    }

    if (!esEmail($email)) {
        $errors[] = "La direccion de correo no es valida";
    }

   if(count($errors) == 0){
    if(emailExiste($email, $con)){
        $sql = $con->prepare("SELECT usuarios.id, clientes.nombres FROM usuarios 
        INNER JOIN clientes ON usuarios.id_cliente=clientes.id
        WHERE clientes.email LIKE ? LIMIT 1");
        $sql->execute([$email]);
        $row = $sql->fetch(PDO::FETCH_ASSOC);
        $user_id = $row['id'];
        $nombres = $row['nombres'];

        $token = solicitaPassword($user_id, $con);

        if($token !== null){
            require_once 'clases/Mailer.php';
            $mailer = new Mailer();

            $url = SITE_URL . '/reset_password.php?id=' . $user_id . '&token=' . $token;

            $asunto = "Recuperar Password - Madera Fina";
            $cuerpo = "Estimado $nombres : <br> Si has solicitado el cambio de tu contraseña daclick en
            el siguiente link <a href='$url'>$url</a>.";
            $cuerpo.= "<br>Si no hicite esta solicitud puedes ignorar el correo";

            if ($mailer->enviarEmail($email, $asunto, $cuerpo)) {
                echo "<p><b>Correo enviado</b></p> $email";
                echo "<p>Hemos enviado un correo a la direccion $email para restablecer la contraseña</p>";
                exit;
            }
        }
        } else {
            $errors[] = "No existe una cuenta asociada a esta direccion de correo";
        }



    }


    
    

    // if (count($errors) == 0) {
    //     // Operación exitosa, redirigir o mostrar mensaje de éxito
    // } else {
    //     print_r($errors);
    // }
}

//session_destroy();

//print_r($_SESSION)

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MaderaFina</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilos.css" rel="stylesheet">

    <style>
        /* Estilos personalizados */
        .navbar {
            background-color: #3e2723;
            /* Café oscuro */
        }

        .navbar-brand,
        .navbar-nav .nav-link {
            color: #fff;
            /* Letras blancas */
        }

        .btn-primary {
            background-color: #c1a174;
            /* Café claro */
            border-color: #c1a174;
            /* Café claro */
        }

        .btn-primary:hover {
            background-color: #c1a174;
            /* Café claro al pasar el mouse */
            border-color: #c1a174;
            /* Café claro al pasar el mouse */
        }

        .btn-outline-warning {
            color: #8b572a;
            /* Café medio */
            border-color: #8b572a;
            /* Café medio */
        }

        .btn-outline-warning:hover {
            background-color: #8b572a;
            /* Café medio al pasar el mouse */
            color: #fff;
            /* Texto blanco al pasar el mouse */
        }

        .btn-success {
            background-color: #8b572a;
            /* Café medio */
            border-color: #8b572a;
            /* Café medio */
        }

        .btn-success:hover {
            background-color: #6e4f29;
            /* Café oscuro al pasar el mouse */
            border-color: #6e4f29;
            /* Café oscuro al pasar el mouse */
        }

        .form-login {
            max-width: 350px;
        }
    </style>


</head>

<body>
    <header data-bs-theme="dark">

        <div class="navbar navbar-expand-lg navbar-dark" style="background-color: #3e2723;">

            <div class="container">
                <a href="#" style="margin-right: 10px;">
                    <img src="img/logo.jpg" alt="Logo de MaderaFina" class="img-fluid" style="max-height: 40px;">
                </a>
                <a href="#" class="navbar-brand">
                    <strong>MaderaFina</strong>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarHeader">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a href="#" class="nav-link active">Catalogo</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">Contacto</a>
                        </li>
                    </ul>
                    <a href="checkout.php" class="btn btn-primary">
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAACXBIWXMAAAsTAAALEwEAmpwYAAABV0lEQVR4nLWVTyuEURTGf0WhNFnIQgk12SmfwG4s2NhIWVPzBSSysGSrrHwAErMQCzUrY2cpFnaz1EiRKfl3dfWot0lzz33feZ86m3PPeX63+77nXoAa4BLxDtwCS3RYtRbQX3wDM+SobmBTsDNy1iDwCbwB/YFap0itKxnM5w1al8F+3qBJGXwAXy1mLhDJujpQCsHqbQycEeSjGgLtqfAy5dFtae0iBJpVof8DhyJBXcC91sohUC/QVPFyJGhB+QegD4NO1XBOnK7Vt2FtKKvBD2/B2FNSzwswYAWNJI5n0dhTVf0OkbpR44GhdkoXsj+B4VjQtkDPQE+g9sh4o/yracOQukT4cZhI+3Q8GSFNYJUMOpTRWhYTi+YEetUw+mHOTbsR3+kRKGaBrQB3ej7agRpZQeNABTgBxgz51Kokdu1NQ/mOgI4N+dTyx+J37M1GDflf/QC6iamAjtlFMgAAAABJRU5ErkJggg==">
                        Carrito <span id="num_cart" class="badge bg-secondary"><?php echo $num_cart; ?></span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <main class="form-login m-auto pt-4">
        <h3>Recuperar Contraseña</h3>

        <?php mostrarMensajes($errors); ?>
        <form action="recupera.php" method="post" class="row g-3" autocomplete="off">
        <div class="form-floating">
                <input class="form-control" type="email" name="email" id="email" placeholder="Correro Electronico">
                <label for="email">Correo Electronico</label>
            </div>
            <div class="d-grid gap-3 col-12">
                <button type="submit" class="btn btn-primary">Continuar</button>
            </div>
            <hr>
            <div class="col-12">
                ¿No tiene cuenta? <a href="registro.php">Registrate aqui con tu cuenta de Gmail</a>
            </div>
        </form>
    </main>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    


</body>

</html>