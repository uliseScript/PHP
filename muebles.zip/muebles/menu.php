<header data-bs-theme="dark">
    <div class="navbar navbar-expand-lg navbar-dark" style="background-color: #3e2723;">
        <div class="container">
            <a href="#" style="margin-right: 10px;">
                <img src="img/logo.jpg" alt="Logo de MaderaFina" class="img-fluid" style="max-height: 40px;">
            </a>
            <a href="http://localhost/muebles/" class="navbar-brand">
                <strong>MaderaFina</strong>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarHeader">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a href="#" class="nav-link active">Catalogo</a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link ">Contacto</a>
                    </li>
                </ul>
                <a href="checkout.php" class="btn btn-primary me-2 btn-sm">
                    <i class="fa-solid fa-cart-shopping"></i>
                    Carrito <span id="num_cart" class="badge bg-secondary"><?php echo $num_cart; ?></span>
                </a>
                <a href="http://localhost/muebles/admin/" class="btn btn-primary me-2 btn-sm">
                <i class="fa-solid fa-user-secret"></i>
                    Administrador Inicio <span id="num_cart" class="badge bg-secondary"></span>
                </a>
                <?php if (isset($_SESSION['user_id'])) { ?>
                    <div class="dropdown">
                        <button class="btn btn-primary btn-sm" id="btn_session" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-solid fa-user"></i>&nbsp;<?php echo $_SESSION['user_name']; ?>
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="btn_session">
                            <li><a class="dropdown-item" href="compras.php">
                                <i class="fa-solid fa-bag-shopping"></i>&nbsp;Mis Compras</a></li>
                                <li><a class="dropdown-item" href="logout.php">
                                <i class="fa-solid fa-right-to-bracket"></i>&nbsp;Cerrar Sesion</a></li>
                        </ul>
                    </div>
                <?php } else {  ?>
                    <a href="login.php" class="btn btn-primary btn-sm">
                        <i class="fa-solid fa-user"></i>&nbsp;Ingresar
                    </a>
                <?php } ?>
            </div>
        </div>
    </div>
</header>
