<?php
require_once 'config/config.php';
$db = new DataBase();
$con = $db->conectar();

$sql = $con->prepare("SELECT id, nombre, precio FROM productos WHERE activo=1");
$sql->execute();
$resultado = $sql->fetchAll(PDO::FETCH_ASSOC);



//session_destroy();

//print_r($_SESSION);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MaderaFina</title>
    <script src="https://kit.fontawesome.com/46ed41e555.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
    <link rel="stylesheet" href="css/estilos.css" rel="stylesheet">

    <style>
        /* Estilos personalizados */
        .navbar {
            background-color: #3e2723; /* Café oscuro */
        }

        .navbar-brand,
        .navbar-nav .nav-link {
            color: #fff; /* Letras blancas */
        }

        .btn-primary {
            background-color: #c1a174; /* Café claro */
            border-color: #c1a174; /* Café claro */
        }

        .btn-primary:hover {
            background-color: #c1a174; /* Café claro al pasar el mouse */
            border-color: #c1a174; /* Café claro al pasar el mouse */
        }

        .btn-outline-warning {
            color: #8b572a; /* Café medio */
            border-color: #8b572a; /* Café medio */
        }

        .btn-outline-warning:hover {
            background-color: #8b572a; /* Café medio al pasar el mouse */
            color: #fff; /* Texto blanco al pasar el mouse */
        }

        .btn-success {
            background-color: #8b572a; /* Café medio */
            border-color: #8b572a; /* Café medio */
        }

        .btn-success:hover {
            background-color: #6e4f29; /* Café oscuro al pasar el mouse */
            border-color: #6e4f29; /* Café oscuro al pasar el mouse */
        }
    </style>


</head>

<body>
<?php include 'menu.php'; ?>

    <main>
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <?php foreach($resultado as $row) { ?>
                <div class="col">
                    <div class="card shadow-sm text-center">
                    <?php 
                    
                    $id = $row['id'];
                    $imagen = "images/productos/". $id . "/sofa.jpg";

                    if(!file_exists($imagen)){
                        $imagen = "images/no-photo.jpg";
                    }
                    
                    
                    ?>
                        <img src="<?php echo $imagen; ?>" class="mx-auto d-block card-img-top card-img-fixed" style="width: 300px; height: 200px;">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $row['nombre'] ?></h5>
                            <p class="card-text">$<?php echo number_format($row['precio'], 2, '.', ','); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <a href="detalles.php?id=<?php echo $row['id']; ?>&token=<?php echo hash_hmac('sha1', $row['id'],KEY_TOKEN); ?>" class="btn btn-success">Detalles</a>
                                </div>
                                <button class="btn btn-success" type="button" onclick="addProducto(<?php echo $row['id']; ?>, '<?php echo hash_hmac('sha1', $row['id'], KEY_TOKEN); ?>')">Agregar al carrito</button>

                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </main>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <script>
        function addProducto(id, token){
            let url = 'clases/carrito.php';
            let formData = new FormData();
            formData.append('id', id);
            formData.append('token', token); 

            fetch(url,{
                method: 'POST',
                body: formData,
                mode: 'cors'
            }).then(response => response.json())
            .then(data =>{
                if(data.ok){
                    let elemento = document.getElementById("num_cart")
                    elemento.innerHTML = data.numero
                }
            })
        }
    </script>

</body>

</html>