<?php 

session_start();

define("ADMIN_URL", "http://localhost/muebles/admin/");