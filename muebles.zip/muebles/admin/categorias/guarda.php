<?php

require_once '../config/databasee.php';
require_once '../config/config.php';




$db = new DataBase();
$con = $db->conectar();

$nombre = $_POST['nombre'];

$sql = $con->prepare("INSERT INTO categorias (nombre, activo) VALUES (?, 1)");
$sql->execute([$nombre]);

header('Location: index.php');

?>

