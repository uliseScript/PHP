<?php

require_once '../config/databasee.php';
require_once '../config/config.php';




$db = new DataBase();
$con = $db->conectar();

$id = $_POST['id'];
$nombre = $_POST['nombre'];

$sql = $con->prepare("UPDATE categorias SET nombre = ? WHERE id = ?");
$sql->execute([$nombre, $id]);

header('Location: index.php');

?>

