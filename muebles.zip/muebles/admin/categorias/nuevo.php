<?php

require_once '../config/databasee.php';
require_once '../config/config.php';
require_once '../header.php';
require_once '../clases/cifrado.php';




$db = new DataBase();
$con = $db->conectar();


?>

<main>
    <div class="container-fluid px-4">
        <h1 class="mt-3">Nueva Categoria</h1>
        <form action="guarda.php" method="post" autocomplete="off">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" class="form-control" name="nombre" id="nombre" requiered autofocus />
            </div>
            <button type="submit" class="btn btn-primary">
                Guarda
            </button>

        </form>
    </div>
</main>



<?php require_once '../footer.php' ?>