<?php

require_once '../config/databasee.php';
require_once '../config/config.php';




$db = new DataBase();
$con = $db->conectar();

$id = $_POST['id'];

$sql = $con->prepare("UPDATE categorias SET activo = 0 WHERE id = ?");
$sql->execute([$id]);

header('Location: index.php');

?>

