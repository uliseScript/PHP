<?php 

require_once 'vendor/autoload.php';

MercadoPago\SDK::setAccessToken('TEST-5782864369266310-031618-ccab618e4391b0b032e1ed0386f6c6ac-711660502');

$preference = new MercadoPago\Preference();

$item = new MercadoPago\Item();
$item->title = 'Producto MF';
$item->quantity = 1;
$item->unit_price = 150.00;
$item->currency_id = "MXN";

$preference->items = array($item);

$preference->back_urls = array(
    "success" => "http://localhost/muebles/capturas.php",
    "failure" => "http://localhost/muebles/fallo.php"
);

$preference->auto_return = "approved"; 
$preference->binary_mode = true; 

$preference->save();

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://sdk.mercadopago.com/js/v2"></script>
</head>
<body>
    <h3>Mercado Pago </h3>

    <div class="checkout-btn"></div>

    <script>
        const mp = new MercadoPago('TEST-e82acb39-e904-4d0c-801a-7d9c8f59f704',{
            locale: 'es-MX'
        });
        mp.checkout({
            preference:{
                id: '<?php echo $preference->id; ?>'
            },
            render:{
                container: '.checkout-btn', 
                label: 'Pagar con MP'
            }
        })
    </script>
    
</body>
</html>